#include "Party.hpp"
#include <cstdlib>

Party::Party(int size, int &customerCounter, const std::vector<std::string> &menu) : size(size) {
    for (int i = 0; i < size; ++i) {
    // Generate a random choice of meal from the menu
        int choice = rand() % menu.size();
        std::string selectedMeal = menu[choice];
        
// Create a new Customer object with a unique name and the selected meal
        customers[i] = new Customer("Customer" + std::to_string(customerCounter++), selectedMeal);
    }
}

//Destructor
Party::~Party() {
    for (int i = 0; i < size; ++i) {
        delete customers[i];
    }
}
