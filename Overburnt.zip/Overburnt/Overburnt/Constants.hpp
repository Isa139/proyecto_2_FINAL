#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

#define SPAWN_RATE 20
#define MIN_PREP_TIME 5
#define MIN_EATING_TIME 5
#define MAX_CUSTOMERS_PER_TABLE 6
#define TABLE_COUNT 6

#endif
