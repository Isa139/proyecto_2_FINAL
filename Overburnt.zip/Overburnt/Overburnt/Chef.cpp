#include "Chef.hpp"
#include "Constants.hpp" 
#include "Utilities.hpp"
#include "Inventory.hpp"
#include <thread>  
#include <chrono>   
#include <iostream>

// Constructor
Chef::Chef(std::queue<Order>* orderQueue, std::mutex* orderQueueMutex)
    : orderQueue(orderQueue), orderQueueMutex(orderQueueMutex) {}

// Calculates the preparation time for a meal with random factors
int Chef::calculatePreparationTime(int preparationTime) {
    int randomFactor = binaryRandom();
    int prepDelay = delay(preparationTime);
    int randomRangeValue = randomRange(0, prepDelay);

    int calculatedTime = preparationTime + (preparationTime * randomFactor * randomRangeValue);
    if (calculatedTime < MIN_PREP_TIME) {
        calculatedTime = MIN_PREP_TIME;
    }
    return calculatedTime;
}

void Chef::cookMealForTable(Party* party, int preparationTime, inventory* inventoryHead, recipe* recipeHead) {
    while (true) {
        std::unique_lock<std::mutex> lock(*orderQueueMutex);

        // Check if there are orders in the queue
        if (orderQueue->empty()) {
            lock.unlock();
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            continue;
        }

        // Process the first order in the queue
        Order order = orderQueue->front();
        orderQueue->pop();

        lock.unlock();

        // Process the order (cook)
        int cookingTime = calculatePreparationTime(preparationTime);
        std::cout << "Chef is preparing " << order.mealName << " for " << order.customerName << " Cooking time: " << cookingTime << " seconds " << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(cookingTime));
        std::cout << "Chef finished preparing " << order.mealName << " for " << order.customerName << "." << std::endl;

        // Update customer's status to 'E' (eating)
        for (int i = 0; i < party->size; ++i) {
            if (party->customers[i]->name == order.customerName) {
                party->customers[i]->status = 'E';
                break; 
            }
        }
    }
}

