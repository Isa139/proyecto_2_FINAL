#include "Waiter.hpp"
#include <gtest/gtest.h>

// Mock Customer class
class MockCustomer : public Customer {
public:
    MockCustomer(const std::string& name, const std::string& meal) : Customer(name, meal) {}

    virtual std::string getMeal() {
        return selectedMeal;
    }
};

// Mock of the inventory structure
struct InventoryMock {
    int ingredient1;
    int ingredient2;
    // Add more ingredients as needed

    InventoryMock(int ing1, int ing2) : ingredient1(ing1), ingredient2(ing2) {}
};

// Function to create a mock inventory
InventoryMock* createInventoryMock() {
    // Initialize the mock inventory with ingredient values
    return new InventoryMock(10, 20); // For example, 10 of ingredient1 and 20 of ingredient2
}

// Function to destroy the mock inventory
void destroyInventoryMock(InventoryMock* inventory) {
    delete inventory;
}

// Test case for Waiter's takeOrder method
TEST(WaiterTest, TakeOrderTest) {
    std::queue<Order> orderQueue;
    std::mutex orderQueueMutex;
    struct recipe* recipeHead = nullptr; // You can initialize this with some mock data

    // Mocking customer and its meal
    MockCustomer customer("John Doe", "Pizza");

    Waiter waiter(&orderQueue, &orderQueueMutex, recipeHead);

    // Mocking inventory copy for testing
    InventoryMock* mockInventory = createInventoryMock();
    // Set up the mock inventory with required ingredients
    // This part depends on your test case scenarios
    // ...

    // Test takeOrder method
    waiter.takeOrder(&customer);

    // Assertions based on the expected behavior
    // For example:
    // ASSERT_EQ(orderQueue.size(), 1); // Assuming the order was successfully added to the queue

    // Clean up any dynamically allocated resources if needed
    destroyInventoryMock(mockInventory);
}

// Main function to run all tests
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
