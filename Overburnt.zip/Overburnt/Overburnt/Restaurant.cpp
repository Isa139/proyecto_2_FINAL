#include "Restaurant.hpp"
#include "Constants.hpp" 
#include "Table.hpp"
#include "Party.hpp"
#include "Waiter.hpp"
#include "Chef.hpp"
#include "Recipe.hpp"

Restaurant::Restaurant() : customerCounter(1) {
// Read recipes from the file and initialize the chef and tables
    struct recipe* recipeHead = readRecipes("data/recipes.csv");
    chef = new Chef(&orderQueue, &orderQueueMutex);
    for (int i = 0; i < TABLE_COUNT; ++i) {
        tables[i] = new Table(i + 1, new Waiter(&orderQueue, &orderQueueMutex, recipeHead), chef);
    }
}

// Function to add a party to the customer queue
void Restaurant::addPartyToQueue(Party *party) {
    std::lock_guard<std::mutex> lock(queueMutex);
    customerQueue.push(party);
}

// Function to assign tables to parties

void Restaurant::assignTables() {
    while (true) {
        for (int i = 0; i < TABLE_COUNT; ++i) {
            if (!tables[i]->isOccupied()) {
                Party *party = nullptr;
                {
                    std::lock_guard<std::mutex> lock(queueMutex);
                    if (!customerQueue.empty()) {
                        party = customerQueue.front();
                        customerQueue.pop();
                    }
                }
                if (party) {
                    tables[i]->assignParty(party);
                }
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

// Function to start threads for managing tables
void Restaurant::threads() {
    std::thread tableThreads[TABLE_COUNT];
    for (int i = 0; i < TABLE_COUNT; ++i) {
        tableThreads[i] = std::thread(&Table::manageTables, tables[i], std::ref(customerQueue), std::ref(queueMutex));
    }

    for (int i = 0; i < TABLE_COUNT; ++i) {
        tableThreads[i].detach();
    }

    assignTables();
}

// Function to create a new party
Party *Restaurant::createParty(int size, const std::vector<std::string> &menu) {
    return new Party(size, customerCounter, menu);
}
