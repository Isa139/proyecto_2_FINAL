#include "Waiter.hpp"
#include "Recipe.hpp" 
#include "Inventory.hpp" 

// Global variables to store the original and copied inventory
struct inventory* originalInventory = nullptr;
struct inventory* inventoryCopy = nullptr;

Waiter::Waiter(std::queue<Order>* orderQueue, std::mutex* orderQueueMutex, struct recipe* recipeHead)
    : orderQueue(orderQueue), orderQueueMutex(orderQueueMutex), recipeHead(recipeHead){
    if (!recipeHead) {
        std::cerr << "Error: Unable to read recipes" << std::endl;
    }

    // Read the inventory from the file and store it as the original inventory
    originalInventory = readInventory("data/inventory.csv");
    if (!originalInventory) {
        std::cerr << "Error: Unable to read inventory" << std::endl;
    }

    inventoryCopy = originalInventory;
}

/// Function to take the order from a customer
void Waiter::takeOrder(Customer* customer) {
    std::lock_guard<std::mutex> lock(*orderQueueMutex);

    std::string selectedMeal = customer->getMeal();
    struct recipe* selectedRecipe = findRecipeByName(recipeHead, selectedMeal.c_str());
    if (!selectedRecipe) {
        std::cout << "Error: Recipe not found for " << selectedMeal << std::endl;
        customer->setStatus('D');
        return;
    }

    // Check the stock in the copied inventory
    std::cout << "Waiter checking stock for " << selectedMeal << std::endl;
    if (checkStock(selectedMeal.c_str(), inventoryCopy, selectedRecipe)) {
        // If there are enough ingredients, put the order in the queue
        Order order(customer->name, selectedMeal);
        orderQueue->push(order);

        // Reduce the ingredients in the copied inventory
        struct ingredient* ingredientPtr = selectedRecipe->ingredients;
        while (ingredientPtr != NULL) {
            alterInventory(inventoryCopy, ingredientPtr->name, -ingredientPtr->quantity);
            ingredientPtr = ingredientPtr->next;
        }

        std::cout << "Waiter took order from " << customer->name << " for " << selectedMeal << std::endl;
        std::cout << "Inventory after order:" << std::endl;
        printInventory(inventoryCopy);

    } else {
        // If there are not enough ingredients available, inform the customer and set their status to 'U'
        std::cout << "Sorry, " << customer->name << ", we are out of stock for " << selectedMeal << std::endl;
        // Inform the customer that their order cannot be fulfilled
        customer->setStatus('D');
    }
}
