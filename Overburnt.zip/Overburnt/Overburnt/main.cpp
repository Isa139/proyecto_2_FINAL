/*Universidad de Costa Rica
Programación 2
Estudiantes:
Maria Paula Leung Ching C34258
Jimena Rivera Álvarez C36561
Maria Isabel Gomez Valdelomar C33305
Maria Jbara Chaktoura B93982*/

#include "Lib.hpp"
#include "Constants.hpp"
#include "Recipe.hpp"
#include "Inventory.hpp"
#include "Utilities.hpp"
#include "Restaurant.hpp"
#include "Constants.hpp"
#include "Menu.hpp"

void runRestaurant(const std::vector<std::string>& menu) {
    srand(static_cast<unsigned int>(time(0)));
    Restaurant restaurant;
    
    // Start the restaurant thread
    std::thread restaurantThread(&Restaurant::threads, &restaurant);

    while (true) {
        int partySize = rand() % 6 + 1;
        
        // Create a party and add it to the restaurant queue
        restaurant.addPartyToQueue(restaurant.createParty(partySize, menu));
        std::this_thread::sleep_for(std::chrono::seconds(SPAWN_RATE));
    }

    restaurantThread.join();
}

int main() {
    initializeRandomSeed();
    printf("Seed initialized\n");

    const char *fileNameR = "/home/jimena/Desktop/Overburnt/Overburnt/data/recipes.csv";
    const char *fileNameI = "/home/jimena/Desktop/Overburnt/Overburnt/data/inventory.csv";
    
// Read recipes from file
    struct recipe *recipes = readRecipes(fileNameR);
    if (!recipes) {
        printf("Failed to read recipes\n");
        return 1;
    }

    printf("Recipes read successfully\n");

    struct inventory *inventory = readInventory(fileNameI);
    if (!inventory) {
        freeRecipes(recipes);
        printf("Failed to read inventory\n");
        return 1;
    }

    printf("Inventory read successfully\n");

// Create menu from recipes
    std::vector<std::string> menu = createMenu(fileNameR);
    if (menu.empty()) {
        std::cerr << "Error: Unable to create the menu from the recipes." << std::endl;
        freeRecipes(recipes);
        freeInventory(inventory);
        return 1;
    }

    printf("Menu created successfully\n");
    
// Start the restaurant simulation in a separate thread
    std::thread restaurantThread(runRestaurant, std::ref(menu));

    restaurantThread.join();

// Free allocated memory
    freeRecipes(recipes);
    freeInventory(inventory);

    return 0;
}

