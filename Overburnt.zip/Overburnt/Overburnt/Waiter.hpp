#ifndef WAITER_HPP
#define WAITER_HPP

#include <queue>
#include <mutex>
#include <condition_variable>
#include "Order.hpp"
#include "Customer.hpp"
#include "Inventory.hpp"

class Waiter {
private:
    std::queue<Order> *orderQueue;
    std::mutex *orderQueueMutex;
    //std::condition_variable chefReady; 
    recipe* recipeHead;
    inventory* inventoryCopy;
    
public:
    Waiter(std::queue<Order>* orderQueue, std::mutex* orderQueueMutex, struct recipe* recipeHead);
    inventory* getInventory() const { return inventoryCopy; }
    recipe* getRecipes() const { return recipeHead; }
    void takeOrder(Customer* customer);
};

#endif
