#ifndef MENU_HPP
#define MENU_HPP

#include <vector>
#include <string>

std::vector<std::string> createMenu(const char *fileNameR);

#endif // MENU_HPP
