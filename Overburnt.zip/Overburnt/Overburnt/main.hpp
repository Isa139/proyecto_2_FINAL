#ifndef MAIN_HPP
#define MAIN_HPP

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <chrono>
#include "Lib.hpp"
#include "Constants.hpp"
#include "Recipe.hpp"
#include "Inventory.hpp"
#include "Utilities.hpp"
#include "Restaurant.hpp"

void runRestaurant(const std::vector<std::string>& menu);

#endif // MAIN_HPP
