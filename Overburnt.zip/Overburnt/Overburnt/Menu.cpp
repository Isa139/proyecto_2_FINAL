#include "Menu.hpp"
#include "Recipe.hpp"
#include "Utilities.hpp"

std::vector<std::string> createMenu(const char* fileNameR) {
    recipe* recipes = readRecipes(fileNameR);
    if (!recipes) {
        return {};
    }

    // Get the names of the recipes
    int recipeCount = 0;
    recipe** recipePtrs = getRecipeNames(recipes, recipeCount);
    if (!recipePtrs) {
        freeRecipes(recipes);
        return {};
    }

    std::vector<std::string> menu;
    for (int i = 0; i < recipeCount; ++i) {
        menu.push_back(std::string(recipePtrs[i]->name));
    }

    freeRecipes(recipes);
    free(recipePtrs);

    return menu;
}
